package org.subhash.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import lombok.AllArgsConstructor;

@RestController
@AllArgsConstructor
public class ClientController {
	
	
	private RestTemplate restTemplate;
	
	private WebClient webClient;
	@GetMapping("/messages")
	public String getMessage(){
		
		String first=restTemplate.getForObject("http:localhost:9090/first", String.class);
		String second=restTemplate.getForObject("http:localhost:9091/second", String.class);
		
		
		
//	String first=webClient.get()
//		.uri("http://localhost:9090/first")
//		.retrieve()
//		.bodyToMono(String.class)
//		.block();
//	
//	String second=webClient.get()
//			.uri("http://localhost:9091/second")
//			.retrieve()
//			.bodyToMono(String.class)
//			.block();
		return first +"-"+ second;
		
	}

}